﻿namespace Szallitas
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblSolution = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.dGSolution = new System.Windows.Forms.DataGridView();
            this.numDemand = new System.Windows.Forms.NumericUpDown();
            this.numSupply = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.dGInput = new System.Windows.Forms.DataGridView();
            this.dGSupply = new System.Windows.Forms.DataGridView();
            this.dGDemand = new System.Windows.Forms.DataGridView();
            this.label3 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGSolution)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numDemand)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numSupply)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dGInput)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dGSupply)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dGDemand)).BeginInit();
            this.SuspendLayout();
            // 
            // lblSolution
            // 
            this.lblSolution.AutoSize = true;
            this.lblSolution.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblSolution.Location = new System.Drawing.Point(805, 442);
            this.lblSolution.Name = "lblSolution";
            this.lblSolution.Size = new System.Drawing.Size(68, 21);
            this.lblSolution.TabIndex = 2;
            this.lblSolution.Text = "Solution";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 82.42549F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 17.57451F));
            this.tableLayoutPanel1.Controls.Add(this.dGSolution, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.numDemand, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.numSupply, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.label2, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.dGInput, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.dGSupply, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.dGDemand, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.lblSolution, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.label3, 0, 4);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(12, 14);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 6;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 31F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 31F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 43F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(973, 756);
            this.tableLayoutPanel1.TabIndex = 4;
            // 
            // dGSolution
            // 
            this.dGSolution.AllowUserToAddRows = false;
            this.dGSolution.AllowUserToDeleteRows = false;
            this.dGSolution.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dGSolution.ColumnHeadersVisible = false;
            this.dGSolution.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dGSolution.Location = new System.Drawing.Point(3, 445);
            this.dGSolution.Name = "dGSolution";
            this.dGSolution.ReadOnly = true;
            this.dGSolution.RowHeadersVisible = false;
            this.dGSolution.Size = new System.Drawing.Size(796, 308);
            this.dGSolution.TabIndex = 3;
            this.dGSolution.Text = "dataGridView1";
            // 
            // numDemand
            // 
            this.numDemand.Location = new System.Drawing.Point(805, 3);
            this.numDemand.Minimum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.numDemand.Name = "numDemand";
            this.numDemand.Size = new System.Drawing.Size(120, 25);
            this.numDemand.TabIndex = 1;
            this.numDemand.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.numDemand.ValueChanged += new System.EventHandler(this.numDemand_ValueChanged);
            // 
            // numSupply
            // 
            this.numSupply.Location = new System.Drawing.Point(805, 34);
            this.numSupply.Minimum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.numSupply.Name = "numSupply";
            this.numSupply.Size = new System.Drawing.Size(120, 25);
            this.numSupply.TabIndex = 2;
            this.numSupply.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.numSupply.ValueChanged += new System.EventHandler(this.numSupply_ValueChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Right;
            this.label1.ImageAlign = System.Drawing.ContentAlignment.TopRight;
            this.label1.Location = new System.Drawing.Point(730, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 31);
            this.label1.TabIndex = 6;
            this.label1.Text = "Demand#";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Dock = System.Windows.Forms.DockStyle.Right;
            this.label2.Location = new System.Drawing.Point(81, 31);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(718, 31);
            this.label2.TabIndex = 7;
            this.label2.Text = "Cost                                                                             " +
    "                                                                                " +
    " Supply#";
            // 
            // dGInput
            // 
            this.dGInput.AllowUserToAddRows = false;
            this.dGInput.AllowUserToDeleteRows = false;
            this.dGInput.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dGInput.ColumnHeadersVisible = false;
            this.dGInput.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dGInput.Location = new System.Drawing.Point(3, 65);
            this.dGInput.Name = "dGInput";
            this.dGInput.RowHeadersVisible = false;
            this.dGInput.Size = new System.Drawing.Size(796, 308);
            this.dGInput.TabIndex = 3;
            this.dGInput.Text = "dataGridView2";
            // 
            // dGSupply
            // 
            this.dGSupply.AllowUserToAddRows = false;
            this.dGSupply.AllowUserToDeleteRows = false;
            this.dGSupply.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dGSupply.ColumnHeadersVisible = false;
            this.dGSupply.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dGSupply.Location = new System.Drawing.Point(805, 65);
            this.dGSupply.Name = "dGSupply";
            this.dGSupply.RowHeadersVisible = false;
            this.dGSupply.Size = new System.Drawing.Size(165, 308);
            this.dGSupply.TabIndex = 4;
            this.dGSupply.Text = "dataGridView1";
            // 
            // dGDemand
            // 
            this.dGDemand.AllowUserToAddRows = false;
            this.dGDemand.AllowUserToDeleteRows = false;
            this.dGDemand.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dGDemand.ColumnHeadersVisible = false;
            this.dGDemand.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dGDemand.Location = new System.Drawing.Point(3, 379);
            this.dGDemand.Name = "dGDemand";
            this.dGDemand.RowHeadersVisible = false;
            this.dGDemand.Size = new System.Drawing.Size(796, 37);
            this.dGDemand.TabIndex = 5;
            this.dGDemand.Text = "dataGridView2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 419);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(76, 19);
            this.label3.TabIndex = 8;
            this.label3.Text = "SOLUTION";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(991, 14);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 26);
            this.button1.TabIndex = 6;
            this.button1.Text = "&Solve";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // imageList1
            // 
            this.imageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.imageList1.ImageSize = new System.Drawing.Size(16, 16);
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1078, 783);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Name = "Form1";
            this.Text = "Transportation";
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGSolution)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numDemand)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numSupply)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dGInput)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dGSupply)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dGDemand)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label lblSolution;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.DataGridView dGSolution;
        private System.Windows.Forms.NumericUpDown numDemand;
        private System.Windows.Forms.NumericUpDown numSupply;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dGInput;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.DataGridView dGSupply;
        private System.Windows.Forms.DataGridView dGDemand;
        private System.Windows.Forms.Label label3;
    }
}

