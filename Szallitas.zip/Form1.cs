﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ILOG.CPLEX;
using ILOG.Concert;
using System.Globalization;
using System.Linq.Expressions;

namespace Szallitas
{

    public partial class Form1 : Form
    {
        public bool IsNumeric(string val) => int.TryParse(val, out int result);

        public Form1()
        {
            InitializeComponent();

            //példa adatokkal feltöltés
            numDemand.Value = 4;
            numSupply.Value = 3;

            dGInput.Rows[0].SetValues("9", "7", "6", "6");
            dGInput.Rows[1].SetValues("8", "6", "7", "9");
            dGInput.Rows[2].SetValues("7", "8", "8", "5");

            dGSupply.Rows[0].Cells[0].Value = "200";
            dGSupply.Rows[1].Cells[0].Value = "120";
            dGSupply.Rows[2].Cells[0].Value = "300";

            dGDemand.RowCount = 1;
            dGDemand.Rows[0].SetValues("150", "200", "150", "120");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //input adatok ellenőrzése
            Boolean hibas = false;

            for (int i = 0; i < numSupply.Value; ++i)
            {
                for (int j = 0; j < numDemand.Value; ++j)
                {
                    try
                    {
                        Convert.ToInt32(dGInput.Rows[i].Cells[j].Value);
                    }
                    catch
                    {
                        MessageBox.Show("Cost is incorrect!");
                        hibas = true;
                    }
                }
            }
            try
            {
                Convert.ToInt32(numDemand.Value);
            }
            catch
            {
                MessageBox.Show("Demand is incorrect!");
            }
            try
            {
                Convert.ToInt32(numSupply.Value);
            }
            catch
            {
                MessageBox.Show("Supply is incorrect!");
            }

            if (!hibas)
            {
                try
                {
                    Cplex cplex = new Cplex();

                    //input adatok, változók feltöltése
                    int nbDemand = Convert.ToInt32(numDemand.Value);
                    int nbSupply = Convert.ToInt32(numSupply.Value);
                    int SumSupply = 0;
                    int SumDemand = 0;
                    double[] Sor = { };

                    int[] supply = new int [nbSupply];
                    for (int i = 0; i < nbSupply; ++i)
                    {
                        supply[i] = Convert.ToInt32(dGSupply.Rows[i].Cells[0].Value);
                        SumSupply = SumSupply +supply[i];
                    }

                    int[] demand = new int [nbDemand]; 
                    for (int j = 0; j < nbDemand; ++j)
                    {
                        demand[j] = Convert.ToInt32(dGDemand.Rows[0].Cells[j].Value);
                        SumDemand = SumDemand + demand[j];
                    }

                    //Ha demand és a supply összegei nem egyeznek meg, akkor felveszünk egy fiktív vevőt vagy fiktív eladót 0 költséggel
                    if (SumDemand > SumSupply)
                    {
                        numSupply.UpButton();
                        nbSupply++;
                        Array.Resize(ref supply, supply.Length + 1);
                        supply[supply.GetUpperBound(0)] = SumDemand - SumSupply;

                        dGSupply.Rows[nbSupply-1].Cells[0].Value = SumDemand - SumSupply;

                        for (int j = 0; j < nbDemand; ++j)
                        {
                            dGInput.Rows[nbSupply-1].Cells[j].Value = 0;
                        }
                    }
                    if (SumSupply > SumDemand)
                    {
                        numDemand.UpButton();
                        nbDemand++;
                        Array.Resize(ref demand, demand.Length + 1);
                        demand[demand.GetUpperBound(0)] = SumSupply - SumDemand;

                        dGDemand.Rows[0].Cells[nbDemand-1].Value = SumSupply - SumDemand;

                        for (int i = 0; i < nbSupply; ++i)
                        {
                            dGInput.Rows[i].Cells[nbDemand-1].Value = 0;
                        }
                    }

                    //CPLEX inputok feltöltése

                    int[,] TransportCost = new int[nbSupply, nbDemand];

                    for (int i = 0; i < nbSupply; ++i)
                    {
                        for (int j = 0; j < nbDemand; ++j)
                        {
                            TransportCost[i,j] = Convert.ToInt32(dGInput.Rows[i].Cells[j].Value);
                        }
                    }

                    INumVar[][] x = new INumVar[nbSupply][];
                    INumVar[][] y = new INumVar[nbSupply][];

                    for (int i = 0; i < nbSupply; i++)
                    {
                        x[i] = cplex.NumVarArray(nbDemand, 0.0, double.MaxValue);
                        y[i] = cplex.NumVarArray(nbDemand, 0.0, double.MaxValue);
                    }
                    
                    //supply demand ellenőrzés
                    for (int i = 0; i < nbSupply; i++)       // supply must meet demand
                        cplex.AddEq(cplex.Sum(x[i]), supply[i]);//supply st

                    for (int j = 0; j < nbDemand; j++)      // demand must meet supply
                    {     
                        ILinearNumExpr v = cplex.LinearNumExpr();
                        for (int i = 0; i < nbSupply; i++)
                            v.AddTerm(1, x[i][j]);          
                        cplex.AddEq(v, demand[j]);          //demand st
                    }
                    

                    //költség számítás

                    ILinearNumExpr expr = cplex.LinearNumExpr();
                    for (int i = 0; i < nbSupply; ++i)
                    {
                        for (int j = 0; j < nbDemand; ++j)
                        {
                            expr.AddTerm(x[i][j], TransportCost[i,j]); //költséggel beszorzom
                        }
                    }

                    //megoldás
                    cplex.AddMinimize(expr);

                    if (cplex.Solve())
                    {
                        //cplex.ExportModel("transport.lp");
                        lblSolution.Text = "Solution: " + cplex.GetStatus();

                        for (int i = 0; i < nbSupply; ++i)
                        {
                            for (int j = 0; j < nbDemand; ++j)
                            {
                                dGSolution.Rows[i].Cells[j].Value = cplex.GetValue(x[i][j]);
                            }
                        }
                        lblSolution.Text = lblSolution.Text + Environment.NewLine + "Cost = " + cplex.ObjValue;
                    }
                    cplex.End();
                }
                catch (ILOG.Concert.Exception exc)
                {
                    MessageBox.Show("CPLEX Error: " + exc);
                }
            }
        }

        private void numDemand_ValueChanged(object sender, EventArgs e)
        {
            dGInput.ColumnCount = Convert.ToInt32(numDemand.Value);
            dGSolution.ColumnCount = Convert.ToInt32(numDemand.Value);
            dGDemand.ColumnCount = Convert.ToInt32(numDemand.Value);
        }

        private void numSupply_ValueChanged(object sender, EventArgs e)
        {
            dGInput.RowCount = Convert.ToInt32(numSupply.Value);
            dGSolution.RowCount = Convert.ToInt32(numSupply.Value);
            dGSupply.RowCount = Convert.ToInt32(numSupply.Value);
        }
    }
}
